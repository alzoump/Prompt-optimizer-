#!/usr/bin/env python3
"""
Prompt Optimizer
Rule-based prompt compression: strips filler, compresses verbose phrasing, and
leaves code, placeholders and document structure untouched.

No API and no model. tiktoken is the only optional dependency, and only for
exact token counts — without it the app falls back to a word-based estimate.

CLI:
    python prompt_optimizer.py                 launch the GUI
    python prompt_optimizer.py --selftest      run the rule-engine test suite
    python prompt_optimizer.py --cli "text"    optimize one prompt and print it
"""

from __future__ import annotations

import os
import re
import sys
import traceback
from datetime import datetime

# ── Token counting ─────────────────────────────────────────────────────────────
try:
    import tiktoken

    _enc = tiktoken.get_encoding("cl100k_base")

    def count_tokens(text: str) -> int:
        return len(_enc.encode(text)) if text else 0

    TOKEN_METHOD = "cl100k exact"
except Exception:  # ImportError, or tiktoken failing to fetch its BPE file
    def count_tokens(text: str) -> int:
        return round(len(text.split()) / 0.75) if text.strip() else 0

    TOKEN_METHOD = "word estimate (install tiktoken for exact)"


# ══════════════════════════════════════════════════════════════════════════════
# Rule-based optimization
# ══════════════════════════════════════════════════════════════════════════════

# Spans that must never be rewritten: fenced code, inline code, quoted text,
# placeholders, URLs and file paths. Exactly ONE capturing group so re.split()
# alternates prose / protected.
#
# Quotes never cross a newline: one unbalanced quote would otherwise swallow
# the rest of the prompt and silently disable every rule after it. Single
# quotes also require a non-word character on each side, so the apostrophes in
# don't and developers' cannot open a span.
_PROTECT_RE = re.compile(
    r"("
    r"```.*?```"                       # fenced code block
    r"|~~~.*?~~~"                      # alternate fence
    r"|`[^`\n]+`"                      # inline code
    r"|\"[^\"\n]*\""                   # "quoted text"
    r"|“[^”\n]*”"                    # curly “quoted text”
    r"|(?<![A-Za-z0-9])'[^'\n]*'(?![A-Za-z0-9])"     # 'quoted text'
    r"|(?<![A-Za-z0-9])‘[^’\n]*’(?![A-Za-z0-9])"   # curly ‘quoted text’
    r"|<[A-Za-z_/][^<>\n]{0,80}>"      # <placeholder> / <html tag>
    r"|\{\{[^}\n]{0,80}\}\}"           # {{template}}
    r"|\$\{[^}\n]{0,80}\}"             # ${var}
    r"|\{[A-Za-z_][A-Za-z0-9_]{0,40}\}"  # {name} format placeholder
    r"|https?://\S+"                   # URL
    r"|[A-Za-z]:\\\\?\S+"              # windows path
    r")",
    re.DOTALL,
)

# Whole sentences that carry no instruction value.
_REMOVE_SENTENCES = [
    r"Feel free to (?:ask|reach out)(?: to me)?(?: if you (?:have|need) (?:any )?(?:further )?(?:questions?|clarification|help))?[^.!?\n]*[.!?]",
    r"Let me know if you (?:need|have|want) (?:anything|any(?:thing)?(?:\s+else)?|further (?:questions?|help)|any (?:clarification|questions?|help))[^.!?\n]*[.!?]",
    r"Don'?t hesitate to ask[^.!?\n]*[.!?]",
    r"I'?m here to help[^.!?\n]*[.!?]",
    r"Thank you (?:so much )?for (?:your (?:help|assistance|question|response|time)|(?:helping|asking))[^.!?\n]*[.!?]",
    r"I appreciate (?:your (?:help|assistance|patience|time)|it)[^.!?\n]*[.!?]",
    r"(?:Try|Do) your (?:very )?best to[^.!?\n]*[.!?]",
    r"I hope (?:this helps|you (?:can help|understand))[^.!?\n]*[.!?]",
    r"Please (?:keep in mind|remember|note|be aware) that you are an AI[^.!?\n]*[.!?]",
    r"You are a (?:helpful|smart|knowledgeable|intelligent|advanced|powerful) (?:AI|assistant|language model)[^.!?\n]*[.!?]",
    r"As an AI(?: language model)?, you[^.!?\n]*[.!?]",
    r"(?:Your|The) (?:response|answer|reply|output) (?:should|must|needs? to|has to) be (?:clear|concise|accurate|detailed|thorough|helpful|correct|precise)[^.!?\n]*[.!?]",
    r"(?:Your|The) (?:response|answer|reply|output) is (?:as )?(?:clear|concise|accurate|detailed|thorough|helpful|correct|precise)[^.!?\n]*[.!?]",
    r"(?:Make|Please make|Ensure|Please ensure) (?:sure )?(?:your|the) (?:response|answer) (?:is|are)[^.!?\n]*[.!?]",
    r"(?:Make|Please make) your (?:answer|response|reply) as (?:\w+ (?:and \w+ )?)?as possible[^.!?\n]*[.!?]",
    r"(?:Be|Please be|Try to be) as (?:\w+ (?:and \w+ )?)?as possible[^.!?\n]*[.!?]",
    r"(?:Write|Give|Provide)(?: your response| your answer)? in a clear and concise (?:manner|way|format)[^.!?\n]*[.!?]",
]

# Applied only at the very start of the prompt.
_STRIP_OPENERS = [
    r"^(?:hi|hello|hey|good (?:morning|afternoon|evening|day)|greetings|howdy)"
    r"(?:\s+(?:there|everyone|all|team))?\b[,!.]*\s*",
    r"^(?:Could|Can|Would|Will) you (?:please )?",
    r"^I(?:'d| would) like you to\s+",
    r"^I want you to\s+",
    r"^I need you to\s+",
    r"^Your task is to\s+",
    r"^Your job is to\s+",
    r"^You are (?:going|expected) to\s+",
]

# Applied at the end of any line.
_STRIP_CLOSERS = [
    r",? if possible\.?(?=$)",
    r",? as best (?:as )?you can\.?(?=$)",
    r",? to the best of your ability\.?(?=$)",
    r",? as (?:accurately|clearly|concisely|clear and concise) as possible\.?(?=$)",
    r",? in a clear and concise (?:manner|way)\.?(?=$)",
    r",? (?:and )?make sure to be (?:thorough|detailed|accurate)\.?(?=$)",
    r",? (?:and )?be as (?:detailed|thorough|helpful) as possible\.?(?=$)",
]

_INLINE_FILLERS = [
    (r"\bplease\b[ \t]*,?[ \t]*", "please"),
    (r"\bkindly\b[ \t]*", "kindly"),
    (r"\b(?:Please )?[Nn]ote that\b[ \t]*", "note that"),
    (r"\b(?:Please )?[Kk]eep in mind that\b[ \t]*", "keep in mind that"),
    (r"\bIt(?:'s| is) (?:important|worth noting) (?:that|to note that)\b[ \t]*", "it is important that"),
    (r"\bJust so you know,?[ \t]*", "just so you know"),
    (r"\bFor your information,?[ \t]*", "for your information"),
    (r"\bFYI,?[ \t]*", "FYI"),
    (r"\bAs an AI(?: language model)?,?[ \t]*", "as an AI"),
    (r"\bAs a helpful assistant,?[ \t]*", "as a helpful assistant"),
]

# ── Phrase compressions ───────────────────────────────────────────────────────
# SAFE: meaning-preserving in essentially every context.
_COMPRESSIONS_SAFE = [
    # Conjunctions / prepositions
    ("in order to",                   "to"),
    ("so as to",                      "to"),
    ("for the purpose of",            "to"),
    ("with the aim of",               "to"),
    ("with the goal of",              "to"),
    ("with a view to",                "to"),
    ("due to the fact that",          "because"),
    ("owing to the fact that",        "because"),
    ("in light of the fact that",     "because"),
    ("for the reason that",           "because"),
    ("in the event that",             "if"),
    ("at this point in time",         "now"),
    ("at the present time",           "now"),
    ("at the present moment",         "now"),
    ("in the near future",            "soon"),
    ("in the not too distant future", "soon"),
    ("prior to",                      "before"),
    ("subsequent to",                 "after"),
    ("in spite of the fact that",     "although"),
    ("despite the fact that",         "although"),
    ("regardless of the fact that",   "although"),
    ("in addition to this",           "also"),
    ("in addition",                   "also"),
    ("furthermore",                   "also"),
    ("moreover",                      "also"),
    ("additionally",                  "also"),
    ("consequently",                  "so"),
    ("therefore",                     "so"),
    ("hence",                         "so"),
    ("on the other hand",             "but"),
    ("nevertheless",                  "but"),
    # Verb phrases
    ("come to the conclusion",        "conclude"),
    ("reach a conclusion",            "conclude"),
    ("make a decision",               "decide"),
    ("make an attempt to",            "try to"),
    ("make use of",                   "use"),
    ("take into consideration",       "consider"),
    ("take into account",             "consider"),
    ("give consideration to",         "consider"),
    ("provide assistance",            "help"),
    ("provide a summary of",          "summarize"),
    ("provide an explanation of",     "explain"),
    ("provide information about",     "describe"),
    ("provide a description of",      "describe"),
    ("give an explanation of",        "explain"),
    ("give a description of",         "describe"),
    ("give a summary of",             "summarize"),
    ("provide a list of",             "list"),
    ("give a list of",                "list"),
    ("is able to",                    "can"),
    ("are able to",                   "can"),
    ("was able to",                   "could"),
    ("were able to",                  "could"),
    ("has the ability to",            "can"),
    ("have the ability to",           "can"),
    # Noun phrases
    ("the majority of",               "most"),
    ("a large number of",             "many"),
    ("a small number of",             "few"),
    ("a number of",                   "some"),
    ("the fact that",                 "that"),
    ("the reason why",                "why"),
    ("the way in which",              "how"),
    ("the extent to which",           "how much"),
    ("with regard to",                "about"),
    ("with respect to",               "about"),
    ("in relation to",                "about"),
    ("pertaining to",                 "about"),
    ("in the context of",             "in"),
    ("by means of",                   "by"),
    ("by virtue of",                  "by"),
    ("on the basis of",               "based on"),
    ("with the exception of",         "except"),
    ("with the help of",              "using"),
    ("with the use of",               "using"),
    ("in the process of",             "while"),
    ("for the sake of",               "for"),
    # Quantifiers
    ("all of the",                    "all the"),
    ("all of my",                     "my"),
    ("all of your",                   "your"),
    ("some of the",                   "some"),
    ("each and every",                "every"),
    ("each of the",                   "each"),
    ("any and all",                   "all"),
    # File-extension tautologies
    ("txt file",                      "txt"),
    ("pdf file",                      "pdf"),
    ("csv file",                      "csv"),
    ("json file",                     "json"),
    ("xml file",                      "xml"),
    ("html file",                     "html"),
    ("markdown file",                 "markdown"),
    ("yaml file",                     "yaml"),
    ("toml file",                     "toml"),
    ("log file",                      "log"),
    # Tautologies
    ("the end result",                "the result"),
    ("a true fact",                   "a fact"),
    ("added bonus",                   "bonus"),
    ("advance planning",              "planning"),
    ("close proximity",               "proximity"),
    ("past history",                  "history"),
    ("sum total",                     "total"),
    ("current status",                "status"),
    ("new innovation",                "innovation"),
    ("very unique",                   "unique"),
    ("completely unique",             "unique"),
    ("absolutely essential",          "essential"),
    ("completely finished",           "finished"),
    ("end result",                    "result"),
    ("future plans",                  "plans"),
    ("past experience",               "experience"),
    ("unexpected surprise",           "surprise"),
    ("free gift",                     "gift"),
]

# AGGRESSIVE: shorter, but can shift nuance. Toggleable in the UI.
_COMPRESSIONS_AGGRESSIVE = [
    ("thus",                          "so"),
    ("in terms of",                   "in"),
    # Relative clause -> preposition
    ("that will have",                "with"),
    ("that would have",               "with"),
    ("that will contain",             "with"),
    ("that contains",                 "with"),
    ("that will include",             "with"),
    ("that includes",                 "with"),
    ("which will have",               "with"),
    ("which contains",                "with"),
    ("which includes",                "with"),
    ("a file that contains",          "a file with"),
    ("a file that has",               "a file with"),
    ("a file that includes",          "a file with"),
    # "that is/are VERB"
    ("that is used to",               "used to"),
    ("that are used to",              "used to"),
    ("that is designed to",           "designed to"),
    ("that are designed to",          "designed to"),
    ("that is able to",               "able to"),
    ("that are able to",              "able to"),
    ("that is needed to",             "to"),
    ("that are needed to",            "to"),
    ("that is required to",           "to"),
    ("that are required to",          "to"),
    ("that needs to",                 "to"),
    ("that need to",                  "to"),
    ("that will be used to",          "to"),
    ("that can be used to",           "to"),
    # List phrasing
    ("a list of all the",             "all the"),
    ("a list of all",                 "all"),
    ("a list of the",                 "the"),
]

# Adverbs that almost never carry instruction weight.
_WEAK_ADVERBS_SAFE = [
    "basically", "essentially", "fundamentally", "literally", "truly",
]
# These can be load-bearing ("just the headers", "completely rewrite").
_WEAK_ADVERBS_AGGRESSIVE = [
    "actually", "absolutely", "completely", "totally", "entirely", "simply", "just",
]

_ABBREVIATIONS = {
    "e.g.", "i.e.", "etc.", "vs.", "cf.", "approx.", "no.", "fig.", "eq.",
    "al.", "mr.", "mrs.", "ms.", "dr.", "st.", "inc.", "ltd.", "jr.", "sr.",
}


# ── Compiled patterns ─────────────────────────────────────────────────────────

def _build_phrase_regex(pairs):
    """One alternation for all phrases, longest first so the longest wins."""
    if not pairs:
        return None, {}
    mapping = {src.lower(): dst for src, dst in pairs}
    ordered = sorted(mapping, key=len, reverse=True)
    pattern = r"\b(" + "|".join(re.escape(p) for p in ordered) + r")\b"
    return re.compile(pattern, re.IGNORECASE), mapping


def _build_word_regex(words):
    if not words:
        return None
    return re.compile(r"\b(?:" + "|".join(re.escape(w) for w in words) + r")\b[ \t]*",
                      re.IGNORECASE)


_REMOVE_SENTENCES_RE = [re.compile(p, re.IGNORECASE) for p in _REMOVE_SENTENCES]
_STRIP_OPENERS_RE = [re.compile(p, re.IGNORECASE) for p in _STRIP_OPENERS]
_STRIP_CLOSERS_RE = [re.compile(p, re.IGNORECASE | re.MULTILINE) for p in _STRIP_CLOSERS]
_INLINE_FILLERS_RE = [(re.compile(p, re.IGNORECASE), label) for p, label in _INLINE_FILLERS]

_COMPRESS_SAFE_RE, _COMPRESS_SAFE_MAP = _build_phrase_regex(_COMPRESSIONS_SAFE)
_COMPRESS_ALL_RE, _COMPRESS_ALL_MAP = _build_phrase_regex(
    _COMPRESSIONS_SAFE + _COMPRESSIONS_AGGRESSIVE)

_ADVERBS_SAFE_RE = _build_word_regex(_WEAK_ADVERBS_SAFE)
_ADVERBS_ALL_RE = _build_word_regex(_WEAK_ADVERBS_SAFE + _WEAK_ADVERBS_AGGRESSIVE)

# "a script that will parse logs" -> "a script to parse logs".
# Requires a determiner+noun before it so "I know that will work" is left alone.
_THAT_WILL_RE = re.compile(
    r"\b(?<!know )(?<!think )(?<!hope )(?<!said )(?<!sure )"
    r"that (?:will|would)\s+(?!have\b|contain\b|include\b|be\b)(?=[a-z])",
    re.IGNORECASE,
)

# Only after real sentence-ending punctuation — never at an arbitrary line start,
# which would capitalize wrapped lines and code that follows a protected span.
_SENT_START_RE = re.compile(r"((?<=[.!?])[ \t\n]+)([a-z])")


# ── Protected-span plumbing ───────────────────────────────────────────────────

def _over_prose(text, fn):
    """Apply fn(str) -> (str, changes) to prose only, leaving protected spans."""
    parts = _PROTECT_RE.split(text)
    changes = []
    for i in range(0, len(parts), 2):          # even indices are prose
        parts[i], ch = fn(parts[i])
        changes.extend(ch)
    return "".join(parts), changes


def _ellipsis(s, n):
    s = " ".join(s.split())
    return s if len(s) <= n else s[: n - 1] + "…"


def _match_case(src: str, dst: str) -> str:
    """Carry the source phrase's leading capitalization onto the replacement."""
    if src[:1].isupper():
        return dst[:1].upper() + dst[1:]
    return dst


# ── Individual passes ─────────────────────────────────────────────────────────

def _remove_sentences(text):
    changes = []
    for pat in _REMOVE_SENTENCES_RE:
        hits = []

        def _rep(m, _hits=hits):
            _hits.append(m.group())
            return " "

        new = pat.sub(_rep, text)
        if hits:
            extra = f"  (+{len(hits) - 1} more)" if len(hits) > 1 else ""
            changes.append(f'Removed: "{_ellipsis(hits[0], 70)}"{extra}')
            text = new
    return text, changes


def _strip_openers(text):
    changes = []
    stripped = text.lstrip()
    lead = text[: len(text) - len(stripped)]
    text = stripped
    for _ in range(3):                          # "Hi, could you please ..."
        before = text
        for pat in _STRIP_OPENERS_RE:
            new = pat.sub("", text, count=1)
            if new != text:
                changes.append("Stripped opener")
                text = new.lstrip()
                break
        if text == before:
            break
    return lead + text, changes


def _strip_closers(text):
    changes = []
    for pat in _STRIP_CLOSERS_RE:
        new = pat.sub(".", text)
        if new != text:
            changes.append("Stripped trailing filler")
            text = new
    return text, changes


def _remove_inline_fillers(text):
    changes = []
    for pat, label in _INLINE_FILLERS_RE:
        new, n = pat.subn("", text)
        if n:
            changes.append(f'Removed filler: "{label}"' + (f"  (x{n})" if n > 1 else ""))
            text = new
    return text, changes


def _apply_compressions(text, aggressive):
    rx = _COMPRESS_ALL_RE if aggressive else _COMPRESS_SAFE_RE
    mapping = _COMPRESS_ALL_MAP if aggressive else _COMPRESS_SAFE_MAP
    if rx is None:
        return text, []

    seen: dict[str, int] = {}

    def _rep(m):
        src = m.group(1)
        key = src.lower()
        seen[key] = seen.get(key, 0) + 1
        return _match_case(src, mapping[key])

    new = rx.sub(_rep, text)
    changes = [
        f'"{k}" -> "{mapping[k]}"' + (f"  (x{n})" if n > 1 else "")
        for k, n in seen.items()
    ]
    return new, changes


def _rewrite_relative_clauses(text):
    new, n = _THAT_WILL_RE.subn("to ", text)
    if n:
        return new, ['"that will/would VERB" -> "to VERB"' + (f"  (x{n})" if n > 1 else "")]
    return text, []


def _remove_weak_adverbs(text, aggressive):
    rx = _ADVERBS_ALL_RE if aggressive else _ADVERBS_SAFE_RE
    if rx is None:
        return text, []
    hits: dict[str, int] = {}

    def _rep(m):
        w = m.group().strip().lower()
        hits[w] = hits.get(w, 0) + 1
        return ""

    new = rx.sub(_rep, text)
    changes = [f'Removed weak adverb: "{w}"' + (f"  (x{n})" if n > 1 else "")
               for w, n in hits.items()]
    return new, changes


# ── Cleanup (structure preserving) ────────────────────────────────────────────

def _fix_capitalization(chunk: str) -> str:
    def _rep(m):
        head = chunk[: m.start()].rstrip()
        tail = head[-10:].split()
        if tail and tail[-1].lower() in _ABBREVIATIONS:
            return m.group(0)                   # "e.g. json" stays lowercase
        return m.group(1) + m.group(2).upper()

    return _SENT_START_RE.sub(_rep, chunk)


def _cleanup(text: str) -> str:
    def _prose(chunk, at_line_start):
        chunk = re.sub(r"[ \t]+", " ", chunk)            # spaces only; keep \n
        chunk = re.sub(r"[ \t]*\n", "\n", chunk)         # trailing space per line
        chunk = re.sub(r"\n{3,}", "\n\n", chunk)         # cap blank runs
        chunk = re.sub(r" +([.,!?;:])", r"\1", chunk)    # " ." -> "."
        chunk = re.sub(r"([,;:])[ \t]*([.!?])", r"\2", chunk)   # ",." -> "."
        chunk = re.sub(r"([.!?])[ \t]*\1+", r"\1", chunk)       # ".." -> "."
        # Punctuation is only orphaned at a real line start. A chunk that merely
        # follows a protected span is mid-sentence, and a leading "." there is
        # that sentence's full stop: Say "done". has to keep it.
        head = r"(^|\n)" if at_line_start else r"(\n)"
        chunk = re.sub(head + r"[ \t]*([,;:.])[ \t]*", r"\1", chunk)
        return _fix_capitalization(chunk)

    parts = _PROTECT_RE.split(text)
    for i in range(0, len(parts), 2):           # even indices are prose
        parts[i] = _prose(parts[i], i == 0 or parts[i - 1].endswith("\n"))
    text = "".join(parts).strip()
    if text[:1].islower():                      # opener stripping can lowercase it
        text = text[0].upper() + text[1:]
    return text


# ── Public entry point ────────────────────────────────────────────────────────

def optimize_prompt(text: str, aggressive: bool = True):
    """Rule-based pass. Returns (optimized, changes, orig_tokens, new_tokens)."""
    original_tokens = count_tokens(text)
    result = text
    all_changes: list[str] = []

    for step in (_remove_sentences, _strip_openers, _strip_closers,
                 _remove_inline_fillers):
        result, ch = _over_prose(result, step)
        all_changes.extend(ch)

    for _ in range(4):                          # iterate until stable
        before = result

        result, ch = _over_prose(result, lambda t: _apply_compressions(t, aggressive))
        all_changes.extend(ch)

        if aggressive:
            result, ch = _over_prose(result, _rewrite_relative_clauses)
            all_changes.extend(ch)

        result, ch = _over_prose(result, lambda t: _remove_weak_adverbs(t, aggressive))
        all_changes.extend(ch)

        if result == before:
            break

    result = _cleanup(result)

    # De-duplicate log lines while preserving order.
    seen = set()
    changes = [c for c in all_changes if not (c in seen or seen.add(c))]
    return result, changes, original_tokens, count_tokens(result)



# ══════════════════════════════════════════════════════════════════════════════
# Develop – XML conversion
# ══════════════════════════════════════════════════════════════════════════════

def _escape_xml(s: str) -> str:
    # Only escape characters that break XML structure; leave quotes readable
    return (s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;"))


def _to_tag_name(phrase: str) -> str:
    """Convert a noun phrase to a snake_case XML tag name."""
    s = re.sub(r"\b(?:the|a|an|their|his|her|its|our|your|my|these|those|this)\b", "", phrase, flags=re.IGNORECASE)
    s = re.sub(r"'s?\b", "", s)
    s = s.strip().lower()
    s = re.sub(r"[\s\-/]+", "_", s)
    s = re.sub(r"[^a-z0-9_]", "", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s or "content"


_COMPOUND_SPLIT_RE = re.compile(
    r',?\s+and\s+(?='
    r'(?:don\'?t\b|do not\b|avoid\b|never\b|keep\b|make sure\b|ensure\b|'
    r'always\b|only\b|use\b|include\b|exclude\b|be\b|stay\b|limit\b|'
    r'mention\b|remind\b|note\b|sign\b|put\b|write\b))',
    re.IGNORECASE,
)

def _split_compound_constraints(lines: list) -> list:
    """Split 'rule A and rule B' compound sentences into separate constraints."""
    result = []
    for line in lines:
        parts = _COMPOUND_SPLIT_RE.split(line)
        if len(parts) > 1:
            for p in parts:
                p = p.strip().rstrip(".,")
                if p:
                    p = p[:1].upper() + p[1:]
                    if not p[-1] in ".!?":
                        p += "."
                    result.append(p)
        else:
            result.append(line)
    return result


def _clean_phrasing(s: str) -> str:
    """Remove context-dependent positional references that read awkwardly in tags."""
    s = re.sub(r'\b(?:the |this |that )?(?:following|below|above)\b(?:\s+(?:text|prompt|content|information|details))?\s*', ' ', s, flags=re.IGNORECASE)
    s = re.sub(r'\s+', ' ', s).strip()
    # Strip leading connector words left over from extraction
    s = re.sub(r'^(?:Also|Additionally|Furthermore|Moreover),?\s+', '', s, flags=re.IGNORECASE)
    return s[:1].upper() + s[1:] if s else s


def _xml_split(text: str) -> list:
    """Split text into sentences, treating newlines as hard boundaries."""
    out = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        # Also split on ." or .' followed by a capital (closed-quote sentence boundary)
        parts = re.split(r'(?<=[.!?])\s+(?=[A-Z"\'])|(?<=[.!?]["\'])\s+(?=[A-Z])', line)
        out.extend(p.strip() for p in parts if p.strip())
    return out


# ── Classification patterns ────────────────────────────────────────────────

_XROLE_RE = re.compile(
    r"^(?:you(?:'re|'ll| are| will)\b|act as\b|assume the role|"
    r"i want you to act as|pretend (?:you are|to be)|"
    r"you(?:'ll| will) be\b)",
    re.IGNORECASE,
)
_XCONTEXT_RE = re.compile(
    r"^(?:he(?:'s| is)\b|she(?:'s| is)\b|they(?:'re|'ve| are| have)\b|"
    r"(?:[A-Z][a-z]+) (?:runs|owns|works|told|is a|has been|expects|chose|sent)\b|"
    r"(?:the |a )?(?:customer|client|user)\b|users?\s+post\b)",
    re.IGNORECASE,
)
_XTASK_RE = re.compile(
    r"^(?:write\b|create\b|generate\b|classify\b|compare\b|analyz[se]\b|"
    r"explain\b|summarize\b|translate\b|list\b|describe\b|review\b|"
    r"find\b|build\b|design\b|draft\b|calculate\b|compute\b|reply\b|"
    r"respond\b|answer\b|handle\b|process\b|evaluate\b|check\b|"
    r"(?:first[,\s]+)?think (?:through|about)\b)",
    re.IGNORECASE,
)
_XCONSTRAINT_RE = re.compile(
    r"\b(?:must(?:n'?t)?|should(?:n'?t)?|need to|have to|ensure\b|make sure|"
    r"do not|don'?t\b|avoid\b|never\b|always\b|only\b|strictly\b|requir(?:e|ed)\b|"
    r"keep (?:it |the |under\b)|under \d+\s*words?|no (?:more than|less than)\b|"
    r"at most\b|at least\b|mention (?:he|she|they)\b)\b",
    re.IGNORECASE,
)
_XRULE_RE = re.compile(
    r"^If\b.{8,}[,;].{5,}",   # "If X, do Y" — conditional logic
    re.IGNORECASE,
)
_XOUTPUT_RE = re.compile(
    r"\b(?:format the output\b|output (?:only|as|just)\b|"
    r"return (?:your |the )?(?:answer|response|result|output)\b|"
    r"return (?:it |them )?as\b|sign it as\b|"
    r"put (?:your |the )?\w+(?:\s+\w+)? (?:inside?|in|within) \w+ tags?\b|"
    r"use a (?:short )?(?:table|format|bullet)\b|"
    r"include a (?:subject line|header|title)\b|"
    r"(?:also\s+)?give a\s+\w+(?:\s+\w+)*\s+(?:level|reason|score|rating|confidence)\b|"
    r"(?:respond|format|structure|write).*\b(?:json|xml|markdown|table|subject line)\b|"
    # Structural reply instructions: "Start with X, then Y, then Z"
    r"start with\b.{5,}(?:,\s*then\b|and then\b)|"
    r"(?:begin|open)\b.{5,}\bthen\b)",
    re.IGNORECASE,
)


# ── Extraction helpers ─────────────────────────────────────────────────────

def _xml_extract_quoted(text: str) -> tuple:
    """Extract 'Here is/Here's [the] NOUN: "content"' blocks."""
    blocks = []
    pat = re.compile(
        r'[Hh]ere(?:\'s| is) (?:the )?([^:"]{3,50}?):\s*"([^"]{10,})"',
        re.DOTALL,
    )
    def _repl(m):
        blocks.append((_to_tag_name(m.group(1)), m.group(2).strip()))
        return " "
    return pat.sub(_repl, text), blocks


def _xml_extract_documents(text: str) -> tuple:
    """Extract 'The first/second X is from Y: details.' document pairs."""
    _ord = {"first": 1, "second": 2, "third": 3, "1st": 1, "2nd": 2, "3rd": 3}
    pat = re.compile(
        # Allow decimal numbers like 6.5% inside the details group
        r'The (first|second|third|1st|2nd|3rd) \w+ is (?:from |by )?([^:,]+?):\s*((?:[^.!?]|\.\d)+[.!?])',
        re.IGNORECASE,
    )
    docs, spans = [], []
    for m in pat.finditer(text):
        docs.append({
            "index": _ord.get(m.group(1).lower(), len(docs) + 1),
            "source": m.group(2).strip(),
            "raw": m.group(3).strip(),
        })
        spans.append((m.start(), m.end()))
    if not docs:
        return text, []
    for s, e in reversed(spans):
        text = text[:s] + " " + text[e:]
    return text, docs


def _xml_parse_doc_fields(source: str, raw: str) -> list:
    kv = [("lender", source)]
    m = re.search(r'([€$£]\s*[\d,]+(?:\.\d+)?)', raw)
    if m:
        kv.append(("amount", m.group(1).replace(" ", "")))
    m = re.search(r'(\d+\.?\d*\s*%)\s*annual', raw, re.IGNORECASE)
    if m:
        kv.append(("interest_rate", m.group(1).strip() + " annual"))
    m = re.search(r'(?:over|for)\s+(\d+\s*years?)', raw, re.IGNORECASE)
    if m:
        kv.append(("term", m.group(1).strip()))
    m = re.search(r'([€$£]\s*[\d,]+)\s*setup fee', raw, re.IGNORECASE)
    if m:
        kv.append(("setup_fee", m.group(1).replace(" ", "")))
    m = re.search(r'(no early repayment penalty|[\d.]+\s*%[^,]*(?:penalty|if[^,]+))', raw, re.IGNORECASE)
    if m:
        v = m.group(1).strip()
        kv.append(("early_repayment_penalty", "None" if v.lower().startswith("no") else v[:1].upper() + v[1:]))
    return kv


def _xml_extract_categories(text: str) -> tuple:
    """Extract 'into ... categories: CAT (desc), ...' definitions.
    Returns (remaining_text, cats, derived_task_or_None)."""
    pat = re.compile(
        r'(?:into (?:one of )?(?:[a-z\d ]+ )?categor(?:ies|y)[^:]*:\s*)'
        r'((?:[A-Z]{2,}(?:\s*\([^)]+\))?\s*(?:,\s*)?(?:or\s+)?){2,})',
        re.IGNORECASE,
    )
    m = pat.search(text)
    if not m:
        return text, [], None
    cats = [(c.group(1), (c.group(2) or "").strip())
            for c in re.compile(r'([A-Z]{2,})(?:\s*\(([^)]+)\))?').finditer(m.group(1))]
    # Locate the enclosing sentence boundaries
    ss = text.rfind(".", 0, m.start())
    ss = ss + 1 if ss >= 0 else 0
    se = text.find(".", m.end())
    se = se + 1 if se >= 0 else len(text)
    sentence = text[ss:se]
    # Try to extract a condensed task from the sentence ("classify X into")
    derived_task = None
    am = re.search(r'(?:to )?(classify|categorize|sort|label|tag)\s+(.+?)\s+into\b', sentence, re.IGNORECASE)
    if am:
        verb = am.group(1)[:1].upper() + am.group(1)[1:].lower()
        obj = am.group(2).strip()
        derived_task = f"{verb} {obj} into exactly one category."
    return text[:ss].rstrip() + " " + text[se:].lstrip(), cats, derived_task


def _xml_extract_examples(text: str) -> tuple:
    """Extract 'For example, "X" is Y. "A" is B.' blocks."""
    fe = re.search(r'[Ff]or example[,.]', text)
    if not fe:
        return text, []
    pair_re = re.compile(r'["\u201c]([^"\u201d]+)["\u201d]\s+is\s+([A-Z]+)')
    seg = text[fe.start():]
    examples = [(p.group(1).strip(), p.group(2).strip()) for p in pair_re.finditer(seg)]
    if not examples:
        return text, []
    # Find end of last example sentence
    last_end = fe.start() + max(p.end() for p in pair_re.finditer(seg))
    period = text.find(".", last_end)
    end = period + 1 if period >= 0 else last_end
    return text[:fe.start()].rstrip() + " " + text[end:].lstrip(), examples


def _xml_extract_priority(text: str) -> tuple:
    """Extract 'If X fits more than one category, pick the most serious...' rule."""
    pat = re.compile(
        r'[^.!?]*\b(?:fits? more than one|pick the most serious|most serious)\b[^.!?]*[.!?]',
        re.IGNORECASE,
    )
    m = pat.search(text)
    if not m:
        return text, None
    return text[:m.start()] + " " + text[m.end():], m.group(0).strip()


def _xml_extract_steps(text: str) -> tuple:
    """Extract 'give them these X steps: item, item, and item.' patterns."""
    pat = re.compile(
        r'(?:[Gg]ive (?:them|him|her) (?:the following )?|[Pp]rovide (?:the following )?)'
        r'([a-z ]+ )?(?:steps?|instructions?|tips?)[:\s]+([^.]+\.)',
        re.IGNORECASE,
    )
    m = pat.search(text)
    if not m:
        return text, None
    noun = (m.group(1) or "").strip()
    tag = _to_tag_name((noun + " steps").strip()) if noun else "steps"
    items = re.split(r',\s*(?:and\s+)?', m.group(2).strip().rstrip("."))
    items = [i.strip().rstrip(".,") for i in items if i.strip()]
    items = [i[:1].upper() + i[1:] + "." for i in items if i]
    return text[:m.start()] + " " + text[m.end():], (tag, "step", items)


def _xml_extract_offer(text: str) -> tuple:
    """Extract 'offer them a discount code (X)' sentences."""
    pat = re.compile(
        r'[A-Z][^.!?]*?\b(?:offer (?:them|him|her)\b|discount code\b|coupon code\b|promo code\b)[^.!?]*[.!?]',
        re.IGNORECASE,
    )
    m = pat.search(text)
    if not m:
        return text, None
    offer = m.group(0).strip()
    if re.search(r'\b(?:must|should|do not|don\'t|ensure)\b', offer, re.IGNORECASE):
        return text, None
    offer = re.sub(r'^[Aa]lso\s+', '', offer)
    offer = re.sub(r'^[Oo]ffer (?:them|him|her)\s+', '', offer, flags=re.IGNORECASE)
    return text[:m.start()] + " " + text[m.end():], offer[:1].upper() + offer[1:]


def _xml_extract_scenarios(text: str) -> tuple:
    """Extract 'both scenarios (X and Y)' → list of scenario strings."""
    pat = re.compile(r'both scenarios?\s*\(([^)]+)\)', re.IGNORECASE)
    m = pat.search(text)
    if not m:
        return text, []
    parts = re.split(r'\s+and\s+', m.group(1))
    scenarios = [p.strip().rstrip(".") for p in parts if p.strip()]
    return text[:m.start()] + "both scenarios" + text[m.end():], scenarios


# ── XML block helpers ──────────────────────────────────────────────────────

def _xml_block(tag, lines, child_tag=None, indent=2):
    if not lines:
        return ""
    pad, inner = " " * indent, " " * (indent + 2)
    rows = [f"{pad}<{tag}>"]
    for line in lines:
        esc = _escape_xml(line)
        rows.append(f"{inner}<{child_tag}>{esc}</{child_tag}>" if child_tag else f"{inner}{esc}")
    rows.append(f"{pad}</{tag}>")
    return "\n".join(rows)


def _xml_inline(tag, content, indent=2):
    if not content:
        return ""
    pad, inner = " " * indent, " " * (indent + 2)
    return f"{pad}<{tag}>\n{inner}{_escape_xml(content)}\n{pad}</{tag}>"


# ── Main conversion ────────────────────────────────────────────────────────

def convert_to_xml(text: str) -> str:
    """Convert a plain-text prompt into a structured XML prompt."""

    # Extraction passes (order matters — documents before offer to avoid false positives)
    text, quoted_blocks          = _xml_extract_quoted(text)
    text, documents              = _xml_extract_documents(text)
    text, categories, cat_task   = _xml_extract_categories(text)
    text, examples               = _xml_extract_examples(text)
    text, priority_rule          = _xml_extract_priority(text)
    text, step_list              = _xml_extract_steps(text)
    text, offer                  = _xml_extract_offer(text)
    text, scenarios              = _xml_extract_scenarios(text)

    # Quoted blocks that are inputs to process go at end; others go before task
    pre_blocks  = [(t, c) for t, c in quoted_blocks if "_to_" not in t]
    post_blocks = [(t, c) for t, c in quoted_blocks if "_to_" in t]

    # Sentence classification
    role_lines, context_lines, task_lines = [], [], []
    constraint_lines, rules_lines, output_lines = [], [], []

    for raw in _xml_split(text):
        s = raw.strip()
        if len(s) < 4:
            continue
        # Strip "I need/want you to" before classifying, then capitalize
        s = re.sub(r'^I(?:\s+need|\s+want) you to\s+', '', s, flags=re.IGNORECASE).strip()
        if not s:
            continue
        s = s[:1].upper() + s[1:]  # ensure first letter is capitalized
        s = _clean_phrasing(s)
        if not s:
            continue

        if _XROLE_RE.match(s):
            role_lines.append(s)
        elif _XOUTPUT_RE.search(s):
            output_lines.append(s)
        elif _XRULE_RE.match(s):
            rules_lines.append(s)
        elif _XCONSTRAINT_RE.search(s) and not re.match(
            # Sentence subject is a thing/place/policy, not the model →
            # it's a fact, not a behavioral rule for the model
            r"^(?:the |our |a |an )\w",
            s, re.IGNORECASE,
        ):
            constraint_lines.append(s)
        elif _XCONTEXT_RE.match(s):
            context_lines.append(s)
        elif _XTASK_RE.match(s):
            task_lines.append(s)
        else:
            # Sentences describing things (article/noun subject) → context
            # Imperative-style short sentences → task
            if re.match(r'^(?:The|A|An|Our|Its|This|That)\s', s):
                context_lines.append(s)
            elif re.match(r'^[A-Z][a-z]+ ', s) and len(s.split()) >= 5:
                context_lines.append(s)
            else:
                task_lines.append(s)

    # Split compound constraints ("rule A and rule B") into separate items
    constraint_lines = _split_compound_constraints(constraint_lines)

    # If category extraction yielded a task sentence, prepend it
    if cat_task and not any(
        re.search(r'\bclassif\w+\b', t, re.IGNORECASE) for t in task_lines
    ):
        task_lines.insert(0, cat_task)

    # Last resort: single flat block → split into task + context
    if (not role_lines and not context_lines
            and not constraint_lines and not output_lines
            and len(task_lines) > 2):
        context_lines = task_lines[1:]
        task_lines = task_lines[:1]

    # Assemble sections in canonical order
    sections = []

    if role_lines:
        sections.append(_xml_block("role", role_lines))

    if context_lines:
        combined = " ".join(context_lines)
        ctx_tag = "client_context" if re.search(
            r'\b[A-Z][a-z]+ (?:runs|owns|works|told|expects|sent|is a|has)\b', combined
        ) else "context"
        sections.append(_xml_block(ctx_tag, context_lines))

    # Pre-task quoted blocks (e.g. customer_email)
    for tag, content in pre_blocks:
        sections.append(_xml_inline(tag, content))

    # Documents (before task, as in ideal output)
    if documents:
        pad, inner, deep = "  ", "    ", "      "
        rows = [f"{pad}<documents>"]
        for doc in sorted(documents, key=lambda d: d["index"]):
            rows.append(f'{inner}<document index="{doc["index"]}">')
            for k, v in _xml_parse_doc_fields(doc["source"], doc["raw"]):
                rows.append(f"{deep}<{k}>{_escape_xml(v)}</{k}>")
            rows.append(f"{inner}</document>")
        rows.append(f"{pad}</documents>")
        sections.append("\n".join(rows))

    if task_lines or scenarios:
        if scenarios:
            pad, inner = "  ", "    "
            rows = [f"{pad}<task>"]
            for line in task_lines:
                rows.append(f"{inner}{_escape_xml(line)}")
            for sc in scenarios:
                rows.append(f"{inner}<scenario>{_escape_xml(sc)}</scenario>")
            rows.append(f"{pad}</task>")
            sections.append("\n".join(rows))
        else:
            sections.append(_xml_block("task", task_lines))

    if step_list:
        list_tag, child_tag, items = step_list
        sections.append(_xml_block(list_tag, items, child_tag=child_tag))

    if categories:
        pad, inner = "  ", "    "
        rows = [f"{pad}<categories>"]
        for name, desc in categories:
            rows.append(f'{inner}<category name="{name}">{_escape_xml(desc)}</category>')
        rows.append(f"{pad}</categories>")
        sections.append("\n".join(rows))

    if priority_rule:
        sections.append(_xml_inline("priority_rule", priority_rule))

    if examples:
        pad, inner, deep = "  ", "    ", "      "
        rows = [f"{pad}<examples>"]
        for comment, category in examples:
            rows.append(f"{inner}<example>")
            rows.append(f"{deep}<comment>{_escape_xml(comment)}</comment>")
            rows.append(f"{deep}<category>{_escape_xml(category)}</category>")
            rows.append(f"{inner}</example>")
        rows.append(f"{pad}</examples>")
        sections.append("\n".join(rows))

    if offer:
        sections.append(_xml_inline("offer", offer))

    if constraint_lines:
        sections.append(_xml_block("constraints", constraint_lines, child_tag="constraint"))

    if rules_lines:
        sections.append(_xml_block("rules", rules_lines, child_tag="rule"))

    if output_lines:
        sections.append(_xml_block("output_format", output_lines))

    # Post-task quoted blocks (e.g. comment_to_classify — the input to process)
    for tag, content in post_blocks:
        sections.append(_xml_inline(tag, content))

    xml = ["<prompt>"]
    for sec in sections:
        if sec:
            xml.append("")
            xml.append(sec)
    xml.append("</prompt>")
    return "\n".join(xml)


# ══════════════════════════════════════════════════════════════════════════════
# Word-level diff
# ══════════════════════════════════════════════════════════════════════════════

# Words, punctuation and whitespace as separate tokens, so a diff lands on word
# boundaries instead of mid-word.
_DIFF_TOKEN_RE = re.compile(r"\s+|\w+|[^\w\s]")


def _diff_spans(before: str, after: str):
    """Character ranges that were cut from `before` and added in `after`.

    Returns (removed, added) as lists of (start, end) offsets. Comparison is
    case-insensitive so the cleanup pass re-capitalizing a sentence does not
    show up as a change.
    """
    from difflib import SequenceMatcher

    a = [(m.group(), m.start(), m.end()) for m in _DIFF_TOKEN_RE.finditer(before)]
    b = [(m.group(), m.start(), m.end()) for m in _DIFF_TOKEN_RE.finditer(after)]
    sm = SequenceMatcher(None,
                         [t[0].lower() for t in a],
                         [t[0].lower() for t in b],
                         autojunk=False)

    def collapse(toks, i1, i2, src):
        """Merge a token run into one span, ignoring runs that are only spaces."""
        if i1 >= i2:
            return None
        start, end = toks[i1][1], toks[i2 - 1][2]
        if not src[start:end].strip():
            return None
        return start, end

    removed, added = [], []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag in ("delete", "replace"):
            span = collapse(a, i1, i2, before)
            if span:
                removed.append(span)
        if tag in ("insert", "replace"):
            span = collapse(b, j1, j2, after)
            if span:
                added.append(span)
    return removed, added


# ══════════════════════════════════════════════════════════════════════════════
# GUI
# ══════════════════════════════════════════════════════════════════════════════

C = {
    "bg":      "#1e1e2e",
    "surface": "#313244",
    "raised":  "#45475a",
    "primary": "#89b4fa",
    "green":   "#a6e3a1",
    "red":     "#f38ba8",
    "yellow":  "#f9e2af",
    "text":    "#cdd6f4",
    "sub":     "#a6adc8",
}


def _enable_dpi_awareness():
    """Without this Windows bitmap-stretches the window on scaled displays,
    which blurs the text and makes the requested geometry overshoot the screen."""
    if os.name != "nt":
        return
    import ctypes
    for call in (lambda: ctypes.windll.shcore.SetProcessDpiAwareness(1),
                 lambda: ctypes.windll.user32.SetProcessDPIAware()):
        try:
            call()
            return
        except Exception:
            continue


def _run_gui():
    _enable_dpi_awareness()

    import tkinter as tk
    from tkinter import messagebox

    class App(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("Prompt Optimizer")
            self.minsize(880, 620)
            self._fit_geometry(1180, 820)
            self.configure(bg=C["bg"])

            self.history: list[dict] = []
            self._count_job = None
            self._diff_basis = None

            self._build()
            self._bind_keys()

        def _fit_geometry(self, want_w, want_h):
            """Never open larger than the screen — the log panel used to fall
            off the bottom on scaled displays."""
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            w = max(880, min(want_w, sw - 80))
            h = max(620, min(want_h, sh - 130))
            self.geometry(f"{w}x{h}+{max(0, (sw - w) // 2)}+{max(0, (sh - h) // 3)}")

        # ── layout ───────────────────────────────────────────────────────────

        def _build(self):
            hdr = tk.Frame(self, bg=C["bg"])
            hdr.pack(fill="x", padx=20, pady=(14, 6))
            tk.Label(hdr, text="Prompt Optimizer", font=("Segoe UI", 20, "bold"),
                     bg=C["bg"], fg=C["primary"]).pack(side="left")
            tk.Label(hdr, text=f"  tokens: {TOKEN_METHOD}", font=("Segoe UI", 9),
                     bg=C["bg"], fg=C["sub"]).pack(side="left", padx=6)

            def toggle(text, var, cmd):
                tk.Checkbutton(
                    hdr, text=text, variable=var, command=cmd,
                    bg=C["bg"], fg=C["text"], selectcolor=C["surface"],
                    activebackground=C["bg"], activeforeground=C["text"],
                    font=("Segoe UI", 9), bd=0, highlightthickness=0,
                ).pack(side="right", padx=(10, 0))

            self.aggressive = tk.BooleanVar(value=True)
            self.show_diff = tk.BooleanVar(value=True)
            self.develop_xml = tk.BooleanVar(value=False)
            toggle("Develop - XML", self.develop_xml, self._on_develop_xml_toggle)
            toggle("Aggressive rules", self.aggressive, self._on_aggressive_toggle)
            toggle("Show diff", self.show_diff, self._on_diff_toggle)

            panels = tk.Frame(self, bg=C["bg"])
            panels.pack(fill="both", expand=True, padx=20, pady=4)
            panels.grid_columnconfigure(0, weight=1, uniform="p")
            panels.grid_columnconfigure(1, weight=1, uniform="p")
            panels.grid_rowconfigure(0, weight=1)

            self.input_text, self.lbl_in = self._panel(panels, 0, "Original Prompt")
            self.output_text, self.lbl_out = self._panel(panels, 1, "Optimized Prompt  (editable)", with_copy=True)

            btn_row = tk.Frame(self, bg=C["bg"])
            btn_row.pack(fill="x", padx=20, pady=6)
            self._btn(btn_row, "Optimize  Ctrl+Enter", self._optimize, C["primary"]).pack(side="left", padx=(0, 8))
            self._btn(btn_row, "Copy Result", self._copy, C["green"]).pack(side="left", padx=(0, 8))
            self._btn(btn_row, "Clear  Ctrl+K", self._clear, C["raised"]).pack(side="left", padx=(0, 8))
            self._btn(btn_row, "History", self._history, C["raised"]).pack(side="left")

            self.lbl_savings = tk.Label(btn_row, text="", font=("Segoe UI", 12, "bold"),
                                        bg=C["bg"], fg=C["green"])
            self.lbl_savings.pack(side="right")

            # ── changes log ──────────────────────────────────────────────────
            log_frame = tk.Frame(self, bg=C["surface"])
            log_frame.pack(fill="x", padx=20, pady=(0, 16))
            tk.Label(log_frame, text="Changes applied:", font=("Segoe UI", 9, "bold"),
                     bg=C["surface"], fg=C["sub"], anchor="w", padx=10, pady=4).pack(fill="x")

            log_body = tk.Frame(log_frame, bg=C["surface"])
            log_body.pack(fill="x")
            self.log = tk.Text(log_body, height=5, width=40, bg=C["surface"], fg=C["text"],
                               font=("Consolas", 9), relief="flat", padx=10, pady=4,
                               state="disabled", wrap="word", highlightthickness=0)
            log_sb = tk.Scrollbar(log_body, command=self.log.yview)
            self.log.config(yscrollcommand=log_sb.set)
            log_sb.pack(side="right", fill="y")
            self.log.pack(side="left", fill="both", expand=True)

        def _panel(self, parent, col, title, with_copy=False):
            frame = tk.Frame(parent, bg=C["surface"])
            frame.grid(row=0, column=col, sticky="nsew",
                       padx=(0, 8) if col == 0 else (0, 0), pady=(0, 8))

            top = tk.Frame(frame, bg=C["surface"])
            top.pack(fill="x", padx=10, pady=(8, 2))
            tk.Label(top, text=title, font=("Segoe UI", 11, "bold"),
                     bg=C["surface"], fg=C["text"]).pack(side="left")
            lbl = tk.Label(top, text="0 tokens", font=("Segoe UI", 9),
                           bg=C["surface"], fg=C["sub"])
            lbl.pack(side="right")
            if with_copy:
                tk.Button(
                    top, text="⎘ Copy", command=self._copy,
                    bg=C["raised"], fg=C["text"], font=("Segoe UI", 8, "bold"),
                    relief="flat", padx=8, pady=2, cursor="hand2", bd=0,
                    activebackground=C["primary"], activeforeground=C["bg"],
                    highlightthickness=0,
                ).pack(side="right", padx=(0, 6))

            body = tk.Frame(frame, bg=C["surface"])
            body.pack(fill="both", expand=True, padx=2, pady=(0, 8))
            # Small requested height + expand=True: the panels grow into
            # whatever is left instead of pushing the lower rows off-window.
            txt = tk.Text(body, bg=C["bg"], fg=C["text"], insertbackground=C["text"],
                          font=("Segoe UI", 11), relief="flat", padx=10, pady=8,
                          wrap="word", selectbackground=C["raised"],
                          undo=True, highlightthickness=0, height=8, width=40)
            sb = tk.Scrollbar(body, command=txt.yview)
            txt.config(yscrollcommand=sb.set)
            sb.pack(side="right", fill="y")
            txt.pack(side="left", fill="both", expand=True)

            # Diff highlighting: struck-through red for what the rules cut,
            # green for what they introduced.
            txt.tag_configure("cut", foreground=C["red"], overstrike=True)
            txt.tag_configure("new", foreground=C["green"])
            return txt, lbl

        def _btn(self, parent, label, cmd, color):
            # Dark buttons need light text; the accent buttons need dark text.
            dark = color in (C["raised"], C["surface"], C["bg"])
            return tk.Button(parent, text=label, command=cmd, bg=color,
                             fg=C["text"] if dark else C["bg"],
                             font=("Segoe UI", 10, "bold"), relief="flat",
                             padx=12, pady=6, cursor="hand2",
                             activebackground=C["primary"] if dark else C["raised"],
                             activeforeground=C["bg"] if dark else C["text"],
                             disabledforeground=C["sub"], bd=0, highlightthickness=0)

        # ── key bindings ─────────────────────────────────────────────────────

        def _bind_keys(self):
            def handler(fn):
                def _h(_event=None):
                    fn()
                    return "break"              # suppress Text's own binding
                return _h

            self.bind_all("<Control-Return>", handler(self._optimize))
            self.bind_all("<Control-k>", handler(self._clear))
            self.bind_all("<Control-K>", handler(self._clear))

            def select_all(event):
                event.widget.tag_add("sel", "1.0", "end-1c")
                event.widget.mark_set("insert", "1.0")
                return "break"

            for w in (self.input_text, self.output_text):
                w.bind("<Control-a>", select_all)
                w.bind("<Control-A>", select_all)

            self.input_text.bind("<KeyRelease>", self._schedule_count)
            self.output_text.bind("<KeyRelease>", self._schedule_count)

        # ── token counting (debounced) ───────────────────────────────────────

        def _schedule_count(self, _=None):
            # Editing either panel invalidates the highlighting, which is
            # anchored to character offsets that have just shifted. Compare
            # against the text the diff was built from: KeyRelease also fires
            # for the Ctrl+Enter that just ran the optimize, and that must not
            # wipe the highlighting it produced.
            if self._diff_basis != (self.input_text.get("1.0", "end-1c"),
                                    self.output_text.get("1.0", "end-1c")):
                self._clear_diff()
            if self._count_job is not None:
                self.after_cancel(self._count_job)
            self._count_job = self.after(200, self._update_counts)

        def _update_counts(self):
            self._count_job = None
            self.lbl_in.config(text=f"{count_tokens(self._get_in()):,} tokens")
            self.lbl_out.config(text=f"{count_tokens(self._get_out()):,} tokens")

        def _get_in(self):
            return self.input_text.get("1.0", "end-1c").strip()

        def _get_out(self):
            return self.output_text.get("1.0", "end-1c").strip()

        def _on_aggressive_toggle(self):
            if self._get_in():
                self._optimize()

        def _on_develop_xml_toggle(self):
            if self._get_in():
                self._optimize()

        # ── diff highlighting ────────────────────────────────────────────────

        def _on_diff_toggle(self):
            if self.show_diff.get():
                self._apply_diff()
            else:
                self._clear_diff()

        def _clear_diff(self):
            self._diff_basis = None
            for w in (self.input_text, self.output_text):
                for tag in ("cut", "new"):
                    w.tag_remove(tag, "1.0", "end")

        def _apply_diff(self):
            """Strike through what was removed, highlight what was added."""
            self._clear_diff()
            if not self.show_diff.get():
                return
            # Raw widget text, NOT the stripped accessors — the offsets returned
            # by _diff_spans are used directly as tkinter indices.
            before = self.input_text.get("1.0", "end-1c")
            after = self.output_text.get("1.0", "end-1c")
            if not before.strip() or not after.strip():
                return
            try:
                removed, added = _diff_spans(before, after)
            except Exception:
                traceback.print_exc()
                return
            for widget, spans, tag in ((self.input_text, removed, "cut"),
                                       (self.output_text, added, "new")):
                for start, end in spans:
                    widget.tag_add(tag,
                                   f"1.0 + {start} chars",
                                   f"1.0 + {end} chars")
            self._diff_basis = (before, after)

        # ── main actions ─────────────────────────────────────────────────────

        def _optimize(self):
            original = self._get_in()
            if not original:
                messagebox.showinfo("Empty", "Paste a prompt to optimize.")
                return

            orig_tok = count_tokens(original)

            if self.develop_xml.get():
                try:
                    result = convert_to_xml(original)
                except Exception as exc:
                    traceback.print_exc()
                    messagebox.showerror("XML conversion failed", f"{type(exc).__name__}: {exc}")
                    return

                result_tok = count_tokens(result)
                self._set_output(result)
                self.lbl_in.config(text=f"{orig_tok:,} tokens")
                self.lbl_out.config(text=f"{result_tok:,} tokens")
                self.lbl_savings.config(text="Converted to XML structure", fg=C["yellow"])
                self._write_log(["Converted plain-text prompt to structured XML"])
                self._apply_diff()
                self._push_history(result, orig_tok, result_tok)
                return

            try:
                optimized, changes, orig_tok, rules_tok = optimize_prompt(
                    original, aggressive=self.aggressive.get())
            except Exception as exc:
                traceback.print_exc()
                messagebox.showerror("Optimize failed", f"{type(exc).__name__}: {exc}")
                return

            self._set_output(optimized)
            self.lbl_in.config(text=f"{orig_tok:,} tokens")
            self.lbl_out.config(text=f"{rules_tok:,} tokens")

            saved = orig_tok - rules_tok
            if saved > 0:
                pct = saved / orig_tok * 100 if orig_tok else 0
                self.lbl_savings.config(text=f"Rules saved {saved} tok ({pct:.1f}%)",
                                        fg=C["green"])
            else:
                self.lbl_savings.config(text="Already concise — no changes", fg=C["sub"])

            self._write_log(changes)
            self._apply_diff()
            self._push_history(optimized, orig_tok, rules_tok)

        def _push_history(self, optimized, orig_tok, new_tok):
            self.history.append(dict(
                time=datetime.now().strftime("%H:%M:%S"),
                original=self._get_in(), optimized=optimized,
                orig_tok=orig_tok, new_tok=new_tok,
            ))

        def _set_output(self, text):
            self.output_text.delete("1.0", "end")
            self.output_text.insert("1.0", text)

        def _write_log(self, changes):
            self.log.config(state="normal")
            self.log.delete("1.0", "end")
            if changes:
                self.log.insert("end", "\n".join(f"• {c}" for c in changes))
            else:
                self.log.insert("end", "No changes — prompt is already concise.")
            self.log.config(state="disabled")

        def _copy(self):
            text = self._get_out()
            if not text:
                messagebox.showinfo("Nothing to copy", "Run Optimize first.")
                return
            self.clipboard_clear()
            self.clipboard_append(text)
            self.update()                       # keep clipboard after exit
            self.lbl_savings.config(text="Copied to clipboard", fg=C["green"])

        def _clear(self):
            self._clear_diff()
            self.input_text.delete("1.0", "end")
            self.output_text.delete("1.0", "end")
            self.lbl_in.config(text="0 tokens")
            self.lbl_out.config(text="0 tokens")
            self.lbl_savings.config(text="")
            self._write_log([])

        def _history(self):
            if not self.history:
                messagebox.showinfo("History", "No optimizations yet this session.")
                return
            win = tk.Toplevel(self)
            win.title("History")
            win.geometry("780x460")
            win.configure(bg=C["bg"])
            txt = tk.Text(win, bg=C["bg"], fg=C["text"], font=("Consolas", 10),
                          relief="flat", padx=12, pady=10, wrap="word",
                          highlightthickness=0)
            sb = tk.Scrollbar(win, command=txt.yview)
            txt.config(yscrollcommand=sb.set)
            sb.pack(side="right", fill="y")
            txt.pack(side="left", fill="both", expand=True)
            for h in reversed(self.history):
                saved = h["orig_tok"] - h["new_tok"]
                txt.insert("end", f"[{h['time']}]  {h['orig_tok']} -> {h['new_tok']} tok "
                                  f"(saved {saved})\n")
                txt.insert("end", f"  Before: {_ellipsis(h['original'], 110)}\n")
                txt.insert("end", f"  After:  {_ellipsis(h['optimized'], 110)}\n\n")
            txt.config(state="disabled")

    App().mainloop()


# ══════════════════════════════════════════════════════════════════════════════
# Self-test
# ══════════════════════════════════════════════════════════════════════════════

_SELFTESTS = [
    # (input, aggressive, predicate(output) -> bool, description)
    ("Write a file that lists all the users.", True,
     lambda o: "file lists" not in o, "no ungrammatical 'file that' collapse"),

    ("Line one.\nLine two.\n\n- bullet a\n- bullet b", True,
     lambda o: o.count("\n") >= 3, "newlines and bullets preserved"),

    ("Fix this:\n```python\ndef f():\n    return 1  # in order to test\n```\nGo.", True,
     lambda o: "def f():\n    return 1  # in order to test" in o,
     "fenced code block untouched"),

    ("I know that will work. Please confirm.", True,
     lambda o: "know that will work" in o, "'I know that will' not rewritten"),

    ("Just the headers, please.", True,
     lambda o: ",." not in o and o.endswith("."), "no orphan punctuation"),

    ("Use e.g. json. then stop.", True,
     lambda o: "e.g. json" in o, "abbreviation not capitalized"),

    ("Could you please provide a summary of this in order to save time?", True,
     lambda o: o.lower().startswith("summarize"), "opener + compression"),

    ("Therefore, use the API.", True,
     lambda o: o.startswith("So,"), "capitalization carried to replacement"),

    ("Send `please note that` verbatim.", True,
     lambda o: "`please note that`" in o, "inline code untouched"),

    ("Replace <please note that> exactly.", True,
     lambda o: "<please note that>" in o, "placeholder untouched"),

    ("Explain it, if possible.\nSummarize it, if possible.", True,
     lambda o: "if possible" not in o, "closers stripped on every line"),

    ("Fetch https://x.com/in%20order%20to/please here.", True,
     lambda o: "https://x.com/in%20order%20to/please" in o, "URL untouched"),

    ("Read the log file and the json file.", True,
     lambda o: "log file" not in o and "json file" not in o, "extension tautologies"),

    ("Just simply do it.", False,
     lambda o: "Just simply" in o, "safe mode keeps load-bearing adverbs"),

    ("A script that will parse logs.", True,
     lambda o: "script to parse" in o, "that-will rewrite still works"),

    ("Hi, can you please write a txt file that will have all of the "
     "good indicators of a good prompt? Thank you for your help.", True,
     lambda o: o.lower().startswith("write a txt with all the"),
     "end-to-end original failing prompt"),

    # ── quoted text is verbatim ──────────────────────────────────────────────

    ('Replace "please note that" exactly.', True,
     lambda o: '"please note that"' in o, "double-quoted text untouched"),

    ('Use “in order to” verbatim.', True,
     lambda o: "“in order to”" in o, "curly-quoted text untouched"),

    ("Replace 'in order to' exactly.", True,
     lambda o: "'in order to'" in o, "single-quoted text untouched"),

    ('Write "a script that will parse logs" and a script that will parse logs.', True,
     lambda o: '"a script that will parse logs"' in o and "and a script to parse logs" in o,
     "same phrase kept in quotes, compressed outside them"),

    ("Don't please note that it works.", True,
     lambda o: "please note that" not in o, "an apostrophe cannot open a quote"),

    ("The developers' guide says to please note that it works.", True,
     lambda o: "please note that" not in o, "a possessive cannot open a quote"),

    ('Say "hello and please note that it works.', True,
     lambda o: "please note that" not in o, "an unbalanced quote protects nothing"),

    ('First "keep this" then\n"and this" too, in order to test.', True,
     lambda o: '"keep this"' in o and '"and this"' in o and "in order to" not in o,
     "quotes do not cross newlines"),

    ('Output the word "done".', True,
     lambda o: o.endswith('"done".'), "full stop survives after a quote"),

    ("Run the command `ls -la`.", True,
     lambda o: o.endswith("`ls -la`."), "full stop survives after inline code"),
]


# Representative real-world prompts. Deliberately mixed: some verbose, some
# already terse. An earlier benchmark repeated one filler-stuffed sentence 200x
# and reported 62% savings, which flattered the engine and made it useless as a
# signal for whether a new rule actually helps.
_BENCH_CORPUS = [
    "Could you please provide a summary of the following text? Please note that it "
    "is important that your response is as clear and concise as possible.",
    "I would like you to write a python script that will parse the log file and "
    "provide a summary of all of the errors.",
    "Rewrite the parse_config function so that it handles all 42 of the edge cases "
    "described in the documentation.",
    "You are a helpful AI assistant. Your task is to take the data provided below "
    "and produce a report with a title, an introduction, three body sections and a "
    "conclusion.",
    "Summarize this article in 3 bullet points.",
    "Explain how a binary search tree works, in order to help me understand the time "
    "complexity. Please make your answer as detailed as possible.",
    "Refactor this code:\n```python\ndef f(a,b):\n    return a+b\n```\n"
    "Keep the behaviour identical and add type hints.",
    "Given the CSV at data/sales.csv, compute the monthly totals for 2025 and output "
    "them as a markdown table sorted by revenue descending.",
    "Act as a senior code reviewer. Review the diff below for correctness bugs. For "
    "each issue, give the file, the line, and a one sentence explanation.",
    "Translate the following paragraph into French, preserving the formal register "
    "and keeping all proper nouns unchanged.",
    "Hi there! I was wondering if you could possibly help me out with something. I "
    "need to understand the difference between a process and a thread.",
    "Write unit tests for the retry_with_backoff helper. Cover the success path, the "
    "exhausted-retries path, and the case where the callable raises a non-retryable "
    "error.",
    "Due to the fact that our API is rate limited, please make use of exponential "
    "backoff in order to avoid hitting the limit. Take into account that the limit "
    "is 100 requests per minute.",
    "extract all email addresses from the text below and return them as a json array",
    "Please note that the deadline is Friday. Keep in mind that the client has "
    "requested a draft in advance. Feel free to ask me if you need any clarification.",
]


def _benchmark():
    """Report honest savings on realistic prompts, plus a throughput figure."""
    import time

    total_a = total_b = 0
    pcts = []
    for src in _BENCH_CORPUS:
        _, _, a, b = optimize_prompt(src, aggressive=True)
        total_a += a
        total_b += b
        pcts.append((a - b) / a * 100 if a else 0.0)
    pcts.sort()
    median = pcts[len(pcts) // 2]
    zeros = sum(1 for x in pcts if x < 0.5)

    print(f"\ncorpus ({len(_BENCH_CORPUS)} realistic prompts):")
    print(f"  total   {total_a:,} -> {total_b:,} tokens "
          f"({(total_a - total_b) / total_a * 100:.1f}% saved)")
    print(f"  median  {median:.0f}%      best {pcts[-1]:.0f}%      "
          f"unchanged {zeros}/{len(pcts)}")

    # Throughput on a large input, so a regression in the regex path is visible.
    big = "\n\n".join(_BENCH_CORPUS) * 40
    t0 = time.perf_counter()
    optimize_prompt(big, aggressive=True)
    dt = time.perf_counter() - t0
    print(f"  speed   {len(big):,} chars in {dt * 1000:.0f} ms")


def _selftest() -> int:
    failed = 0
    checks = 0
    for src, aggr, check, desc in _SELFTESTS:
        out, changes, a, b = optimize_prompt(src, aggressive=aggr)
        ok = False
        try:
            ok = bool(check(out))
        except Exception as exc:
            out = f"{out!r}  <check raised {exc}>"
        checks += 1
        print(f"[{'PASS' if ok else 'FAIL'}] {desc}")
        if not ok:
            failed += 1
            print(f"        in : {src!r}")
            print(f"        out: {out!r}")

    # No-crash fuzz over structural edge cases.
    edge = ["", "   ", "\n\n\n", ".", "please", "```\n```", "<>", "a" * 5000,
            "please " * 500, "in order to " * 300]
    for e in edge:
        try:
            optimize_prompt(e, aggressive=True)
            optimize_prompt(e, aggressive=False)
        except Exception as exc:
            failed += 1
            print(f"[FAIL] edge case {e[:20]!r} raised {type(exc).__name__}: {exc}")

    # Diff-span correctness. Offsets must index the ORIGINAL strings exactly,
    # because the GUI feeds them straight to tkinter as character indices.
    diff_cases = [
        ("Please write the report.", "Write the report.", ["Please"], []),
        ("in order to test", "to test", ["in order"], []),
        ("Summarize this.", "Summarize this.", [], []),
        ("the log file here", "the log here", ["file"], []),
    ]
    for before, after, want_cut, want_new in diff_cases:
        removed, added = _diff_spans(before, after)
        got_cut = [before[s:e].strip() for s, e in removed]
        got_new = [after[s:e].strip() for s, e in added]
        ok = got_cut == want_cut and got_new == want_new
        checks += 1
        print(f"[{'PASS' if ok else 'FAIL'}] diff {before!r} -> {after!r}")
        if not ok:
            failed += 1
            print(f"        cut={got_cut!r} (want {want_cut!r})")
            print(f"        new={got_new!r} (want {want_new!r})")

    # Spans must never fall outside the strings they index.
    for src in _BENCH_CORPUS:
        out, _, _, _ = optimize_prompt(src)
        removed, added = _diff_spans(src, out)
        bad = ([1 for s, e in removed if not (0 <= s < e <= len(src))]
               + [1 for s, e in added if not (0 <= s < e <= len(out))])
        if bad:
            failed += 1
            print(f"[FAIL] diff span out of range for {src[:40]!r}")
    checks += 1
    print("[PASS] diff spans in range across corpus")

    _benchmark()

    print(f"\n{checks - failed}/{checks} checks passed, {failed} failure(s)")
    return 1 if failed else 0


# ══════════════════════════════════════════════════════════════════════════════

def main() -> int:
    args = sys.argv[1:]
    if args and args[0] == "--selftest":
        return _selftest()
    if args and args[0] == "--cli":
        text = " ".join(args[1:]) or sys.stdin.read()
        out, changes, a, b = optimize_prompt(text)
        print(out)
        print(f"\n--- {a} -> {b} tokens ({(a - b) / a * 100:.1f}% saved)"
              if a else "", file=sys.stderr)
        return 0
    _run_gui()
    return 0


if __name__ == "__main__":
    sys.exit(main())
